package com.example.projeto1.repository.retrofit

data class ResponseData(
    val message: String
)