package com.example.projeto1.repository.retrofit

data class UserData (
    val username : String,
    val password : String
)