package com.example.projeto1.repository.room
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface SavedLoginDao {

    @Insert
    suspend fun insert(loginTry : SavedLogin)

    @Query("Select * from SavedLogin Order by id DESC")
    suspend fun getAll() : List<SavedLogin>

    @Query("Select * from SavedLogin Order by id DESC")
    fun getAllInFlow() : Flow<List<SavedLogin>>

}